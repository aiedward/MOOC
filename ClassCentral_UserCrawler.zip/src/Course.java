
public class Course {
	
	
	public String title;
	public String provider;
	public String school;
	
	public String status;
	public String url;
	
}
