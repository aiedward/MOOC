import java.util.ArrayList;
import java.util.Date;


public class Data {
	
	
	public String name;
	
	public String location;
	
	public String education;
	
	public String professional;
	
	public String enrolled_status;
	
	public String course_url;
	
	public String course_title;
	
	public ArrayList<Course> courseList;
		
	
	
	public String title;
	
	public ArrayList<String> sessionList;

	public String description;
	
	public String price;
	
	public String course_index;
	
	public String url;
	
	public String date;
	
	public String subject;
	
	public String provider;

	public String id;
	
	public String school;
	
	public String ratingValue;
	
	public String reviewCount; 

	public String language;

	public String pace;

	public String certification;

	public String course_hour;

	public String course_length;
	
}


