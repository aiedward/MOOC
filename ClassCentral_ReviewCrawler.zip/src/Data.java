import java.util.ArrayList;
import java.util.Date;


public class Data {
	/**
	 * Title of edX course
	 */
	public String title;
	
	public String reviewer_id;
	
	public String reviewer_url;
	
	public String review_contents;
	
	public String review_date;
	
	public String reviewer_rating_value;
	
	public String review_sum;
	
	
	
	public String course_index;
	
	public String url;
	
	public String date;
	
	public String subject;
	
	public String provider;

	public String id;
		
	public String school;
	
	public String ratingValue;
	
	public String reviewCount; 

	
}
